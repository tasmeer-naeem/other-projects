import React, { Component } from 'react';

class userData extends Component {
    state = {  }
    render() {
        return (
            <>
            <h3>User Data Component</h3>
            </>
        );
    }
}

export default userData;