import pandas as pd
from openpyxl import workbook
import xlsxwriter

home_page=open('home.html','w')
home_page.write('<html>\n<head>\n<title>\nHome Page\n</title>\n</head>\n<body>\n<h1>Home Page</h1>\n</body>\n</html>')
home_page.close()

writer=pd.ExcelWriter("new_book.xlsx")
writer.save()
