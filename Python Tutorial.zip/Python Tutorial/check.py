import pandas as pd

pd.__version__

df=pd.read_excel('new_book.xlsx')
print(df)

df=pd.read_excel('book2.xlsx')
print(df)

