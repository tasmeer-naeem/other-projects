from tkinter import *
root=Tk()
root.title("Canvas Widget")
canvas_width=800
canvas_height=400

root.geometry(f"{canvas_width}x{canvas_height}")
can_widget=Canvas(root,width=canvas_width,height=canvas_height)
can_widget.pack()
can_widget.create_line(0,0,800,400, fill="red")   #x1 y1 to x2 y2
can_widget.create_line(0,400,800,0, fill="red")
can_widget.create_rectangle(10,10,600,200,fill="pink")
can_widget.create_oval(50,50,100,300,fill="lightblue")
can_widget.create_text(300,100,text="Python")


root=mainloop()