from tkinter import *
root = Tk()
root.title("My Frame")
root.geometry("666x444")

def home():
    print("Welcome Home Button")

f1=Frame(root,bg="maroon",borderwidth=8,relief=SUNKEN)
f1.pack(side="left" , fill="y")
l1=Label(f1,text="Side bar")
l1.pack(pady=100)

f2=Frame(root,bg="orange",borderwidth=8,relief=SUNKEN)
f2.pack(side="top",fill="x")
l2=Label(f2,text="My Project")
l2.pack(padx=100)

f3=Frame(root,bg="purple",borderwidth=8,relief=SUNKEN)
f3.pack(side="top",fill="x")
b1=Button(f3,bg="black",fg="white",text="About Us",font="16")
b1.pack(side="right",padx=12)
b2=Button(f3,bg="black",fg="white",text="Contact",font="16")
b2.pack(side="right",padx=12)
b3=Button(f3,bg="black",fg="white",text="Products",font="16")
b3.pack(side="right",padx=12)
b4=Button(f3,bg="black",fg="white",text="Home",font="16",command=home)
b4.pack(side="right",padx=12)

f4=Frame(root,bg="green",borderwidth=8,relief=SUNKEN)
f4.pack(side="top",fill="x")
l4=Label(f4,text='''Python is an interpreted high-level general-purpose programming language. \nPython's design philosophy
emphasizes code readability with its notable use of significant indentation. \nIts language constructs as well as
its object-oriented approach aim to help programmers write clear, \nPython is dynamically-typed and 
garbage-collected.''')
l4.pack()

f5=Frame(root,bg="orange",borderwidth=8,relief=SUNKEN)
f5.pack(side="bottom",fill="x")
l5=Label(f5,text="Footer")
l5.pack(padx=100)



#f6=Frame(root,relief=SUNKEN)
#f6.pack(anchor="nw")
#l3=Label(f3,text="My Project")
#l3.pack(padx=100)


root=mainloop()