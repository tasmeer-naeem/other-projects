from tkinter import *
#variable classes in tkinter
#StringVar , DoubleVar , BooleanVar , IntVar
root=Tk()
root.title("Login Page")
root.geometry("650x400")

def getvalue():
    #print(f"{uservalue.get(),passvalue.get(),agevalue.get(),gendervalue.get(),coursesvalue.get(),termvalue.get()}")
    print(f"Username {uservalue.get()}")
    print(f"Password {passvalue.get()}")
    print(f"age {agevalue.get()}")
    print(f"gender {gendervalue.get()}")
    print(f"courses {coursesvalue.get()}")
    with open("records.txt","a") as f:   #a -> append
        f.write(f"{uservalue.get(),passvalue.get(),agevalue.get(),gendervalue.get(),coursesvalue.get(),termvalue.get()}\n")


Label(root,text="Welcome to Registration Page",pady=15,font="ariel 16 bold").grid(row=0,column=3)
user=Label(root,text="Username",font=12)
passs=Label(root,text="Password",font=12)
age=Label(root,text="age",font=12)
gender=Label(root,text="gender",font=12)
courses=Label(root,text="courses",font=12)
user.grid(row=3,column=2)      #user.pack(side=left)
passs.grid(row=4,column=2)
age.grid(row=5,column=2)
gender.grid(row=6,column=2)
courses.grid(row=7,column=2)

uservalue=StringVar()
passvalue=StringVar()
agevalue=IntVar()
gendervalue=StringVar()
coursesvalue=IntVar()
termvalue=IntVar()

userentry=Entry(root,textvariable=uservalue)
passentry=Entry(root,textvariable=passvalue)
ageentry=Entry(root,textvariable=agevalue)
genderentry=Entry(root,textvariable=gendervalue)
coursesentry=Entry(root,textvariable=coursesvalue)

userentry.grid(row=3,column=3)
passentry.grid(row=4,column=3)
ageentry.grid(row=5,column=3)
genderentry.grid(row=6,column=3)
coursesentry.grid(row=7,column=3)

terms=Checkbutton(text="I Agree terms and conditions",variable=termvalue).grid(row=8,column=3)

Button(text="Submit",font="georgia 16 bold",command=getvalue).grid(row=9,column=3)
#b1=Button(root,text="Submit",font=14)
#b1.grid(row=4)

root=mainloop()