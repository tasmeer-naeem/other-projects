from tkinter import *
from tkinter import PhotoImage
#from PIL import Image, ImageTk   #for jpg image

codewithharry_root=Tk()
codewithharry_root.title("My FIRST GUI")

#widthxheight
codewithharry_root.geometry("830x600")

#width,height
codewithharry_root.minsize(200,100)

#width,height
codewithharry_root.maxsize(1200,700)

label1=Label(text="Code With Harry Tutorial")
label1.pack()

photo1=PhotoImage(file="one.png")
label2=Label(image=photo1)
label2.pack()

#jpgimage=Image.open("image.jpg")
#photo2=ImageTk.PhotoImage(jpgimage)
#label3=Label(image=photo2)
#label3.pack()

#important label options
#text - add the text
#bg - background
#fg - foreground
#font - set the font
#padx -  x pdding
#pady - y padding
#relief - boder stying - SUNKEN , GROOVE , RIDGE , RAISED

#important pack options
#anchor=nw,ne,sw,se
#side=top,bottom,lft,right
#fill
#padx
#pady

label4=Label(text='''Python is an interpreted high-level general-purpose programming language. \nPython's design philosophy
emphasizes code readability with its notable use of significant indentation. \nIts language constructs as well as
its object-oriented approach aim to help programmers write clear, \nPython is dynamically-typed and 
garbage-collected.''',bg="brown",fg="white",font="georgia 12 bold",padx=3,pady=3,borderwidth=3,relief=SUNKEN)

label4.pack(side="top" ,anchor="nw",fill=X,padx=30,pady=30)

#gui logic here
codewithharry_root.mainloop()
