from tkinter import *

root=Tk()
root.geometry("650x400")

def click(event):
    print(f"you click at {event.x},{event.y}")

widget=Button(root,text="Click me")
widget.pack(side="top")

widget.bind("<Button-1>",click)
widget.bind("<Double-1>",quit)

root=mainloop()