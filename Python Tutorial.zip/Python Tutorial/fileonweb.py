import requests as requests
from flask import Flask

url="https://httpbin.org/post"
#url="http://127.0.0.1:5000/upload"

sample_file = open("book2.xlsx", "rb")
upload_file = {"Uploaded file": sample_file}
r = requests.post(url, files = upload_file)

print(r.text)