<script setup>
// import { RouterLink, RouterView } from 'vue-router'
import { RouterView } from 'vue-router'
import DataTable from './components/dataTable.vue'

</script>

<template>
 
 <DataTable />
 

  <RouterView />
</template>
